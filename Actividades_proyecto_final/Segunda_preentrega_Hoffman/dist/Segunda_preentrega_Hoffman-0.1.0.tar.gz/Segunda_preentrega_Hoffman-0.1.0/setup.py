from setuptools import setup

setup(
    name='Segunda_preentrega_Hoffman',
    version='0.1.0',
    author='Lara Hoffman',
    author_email='larahoff02@gmail.com',
    description='Esta es la segunda pre-entrega del proyecto final de Python',
    packages=['base_cliente', 'cliente_mayorista', 'cliente_minorista','primera_preentrega']
)